"use client";

import dynamic from "next/dynamic";
import { I18nProvider, useI18n } from "@/lib/i18n";
import { Hero } from "@/components/sections/hero";
import { Navigation } from "@/components/sections/navigation";
import { ScrollProgress } from "@/components/sections/scroll-progress";
import { BackToTop } from "@/components/sections/back-to-top";
import { WhisperProvider, WhisperFloat, CollectedWhispers } from "@/components/whispering-ink";

/* Critical above-fold — loaded immediately */
const StatsCounter = dynamic(() => import("@/components/sections/stats-counter"), {
  ssr: false,
  loading: () => <div className="h-40" />,
});

/* Below-fold — lazy loaded with code splitting */
const About = dynamic(() => import("@/components/sections/about").then((m) => ({ default: m.About })), {
  ssr: false,
  loading: () => <div className="h-[600px]" />,
});

const Performances = dynamic(() => import("@/components/sections/performances"), {
  ssr: false,
  loading: () => <div className="h-[800px]" />,
});

const EmotionalMap = dynamic(() => import("@/components/sections/emotional-map"), {
  ssr: false,
  loading: () => <div className="h-[600px]" />,
});

const LivingStage = dynamic(() => import("@/components/sections/living-stage"), {
  ssr: false,
  loading: () => <div />,
});

const Testimonials = dynamic(() => import("@/components/sections/cinematic-testimonials"), {
  ssr: false,
  loading: () => <div className="h-[500px]" />,
});

const GallerySection = dynamic(() => import("@/components/sections/gallery"), {
  ssr: false,
  loading: () => <div className="h-[600px]" />,
});

const VoicedCanvasSection = dynamic(() => import("@/components/sections/voiced-canvas-section").then((m) => ({ default: m.VoicedCanvasSection })), {
  ssr: false,
  loading: () => <div className="h-[500px]" />,
});

const Booking = dynamic(() => import("@/components/sections/booking"), {
  ssr: false,
  loading: () => <div className="h-[800px]" />,
});

const MirrorRoom = dynamic(() => import("@/components/sections/mirror-room").then((m) => ({ default: m.MirrorRoom })), {
  ssr: false,
  loading: () => <div className="h-[500px]" />,
});

const OriginThread = dynamic(() => import("@/components/sections/origin-thread").then((m) => ({ default: m.OriginThread })), {
  ssr: false,
  loading: () => <div className="h-[800px]" />,
});

const KomProverbLoader = dynamic(() => import("@/components/sections/kom-codex").then((m) => ({ default: m.KomProverbLoader })), {
  ssr: false,
  loading: () => <div className="h-10" />,
});

const KomPatternDivider = dynamic(() => import("@/components/sections/kom-codex").then((m) => ({ default: m.KomPatternDivider })), {
  ssr: false,
  loading: () => <div className="h-10" />,
});

const Newsletter = dynamic(() => import("@/components/sections/newsletter"), {
  ssr: false,
  loading: () => <div className="h-[300px]" />,
});

const Footer = dynamic(() => import("@/components/sections/footer"), {
  ssr: false,
  loading: () => <div className="h-[200px]" />,
});

/* ------------------------------------------------------------------ */
/*  Inner app: has access to useI18n() for WhisperProvider lang sync  */
/* ------------------------------------------------------------------ */

function AppContent() {
  const { lang } = useI18n();

  return (
    <WhisperProvider lang={lang}>
      <div className="flex min-h-screen flex-col">
        {/* Skip to content link for accessibility */}
        <a
          href="#about"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded focus:bg-gold focus:px-4 focus:py-2 focus:text-void focus:outline-none"
        >
          Skip to main content
        </a>

        {/* Scroll progress bar */}
        <ScrollProgress />

        {/* Sticky navigation — appears after hero */}
        <Navigation />

        {/* Main content */}
        <main className="flex-1 flex flex-col">
          <Hero />
          <StatsCounter />
          <LivingStage index={0} />
          <About />
          <KomPatternDivider />
          <LivingStage index={1} />
          <Performances />
          <KomPatternDivider />
          <LivingStage index={2} />
          <EmotionalMap />
          <KomPatternDivider />
          <LivingStage index={3} />
          <Testimonials />
          <LivingStage index={4} />
          <GallerySection />
          <KomPatternDivider />
          <LivingStage index={0} />
          <OriginThread />
          <KomPatternDivider />
          <LivingStage index={1} />
          <MirrorRoom />
          <KomProverbLoader />
          <KomPatternDivider />
          <LivingStage index={2} />
          <VoicedCanvasSection />
          <Booking />
          <Newsletter />
        </main>

        <Footer />

        {/* Back to top button */}
        <BackToTop />

        {/* Whispering Ink — floating whisper + collected panel */}
        <WhisperFloat />
        <CollectedWhispers />
      </div>
    </WhisperProvider>
  );
}

export default function Home() {
  return (
    <I18nProvider>
      <AppContent />
    </I18nProvider>
  );
}